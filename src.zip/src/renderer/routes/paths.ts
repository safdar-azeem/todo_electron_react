export const Home:string = '/';
export const ADD_CONTACT: string = '/add';
export const EDIT_CONTACT: string = '/edit/:id';
